from django.shortcuts import render, redirect
from .models import Produto, MovimentacaoEstoque

def listar_produtos(request):
    produtos = Produto.objects.all()
    return render(request, 'estoque/listar_produtos.html', {'produtos': produtos})

def detalhes_produto(request, produto_id):
    produto = Produto.objects.get(id=produto_id)
    return render(request, 'estoque/detalhes_produto.html', {'produto': produto})

def adicionar_movimentacao(request, produto_id):
    produto = Produto.objects.get(id=produto_id)
    
    if request.method == 'POST':
        tipo = request.POST['tipo']
        quantidade = int(request.POST['quantidade'])
        
        movimentacao = MovimentacaoEstoque(
            produto=produto, quantidade=quantidade, tipo=tipo)
        movimentacao.save()

        # Atualizar o estoque do produto
        if tipo == 'entrada':
            produto.quantidade_em_estoque += quantidade
        elif tipo == 'saida':
            produto.quantidade_em_estoque -= quantidade
        produto.save()

        return redirect('detalhes_produto', produto_id=produto.id)
    
    return render(request, 'estoque/adicionar_movimentacao.html', {'produto': produto})