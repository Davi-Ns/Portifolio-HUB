from django.urls import path
from . import views

urlpatterns = [
    path('produtos/', views.listar_produtos, name='listar_produtos'),
    path('produtos/<int:produto_id>/', views.detalhes_produto, name='detalhes_produto'),
    path('produtos/<int:produto_id>/movimentacao/', views.adicionar_movimentacao, name='adicionar_movimentacao'),
]