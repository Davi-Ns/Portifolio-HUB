from django.db import models

class Produto(models.Model):
    nome = models.CharField(max_length=100)
    descricao = models.TextField(blank=True, null=True)
    preco = models.DecimalField(max_digits=10, decimal_places=2)
    quantidade_em_estoque = models.IntegerField(default=0)

    def __str__(self):
        return self.nome

class MovimentacaoEstoque(models.Model):
    TIPO_MOVIMENTACAO = (
        ('entrada', 'Entrada'),
        ('saida', 'Saída'),
    )
    produto = models.ForeignKey(Produto, on_delete=models.CASCADE)
    quantidade = models.IntegerField()
    tipo = models.CharField(max_length=7, choices=TIPO_MOVIMENTACAO)
    data = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f'{self.tipo.capitalize()} - {self.produto.nome} ({self.quantidade})'